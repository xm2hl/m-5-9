import Foundation

// Create empty array of type Int

// add five values to the array

// Use a for-in loop to iterate through the array


// Create a dictionary with string keys and integer values

// Use a for-in loop to iterate through the dictionary


// Create a while loop that counts up to 100


// Create a repeat-while loop that counts down from 10


// Use a for-in loop to iterate through a range of numbers


// Use a for-in loop to iterate through a range of numbers with a step
//: OUTPUT
/*
 0
 2
 4
 6
 8
 */

// Create an array of strings and use a for-in loop to print each one


// Use a for-in loop with the enumerated() method to iterate through an array and print the index and value of each element


/*
 Write a swift program to formulate this shape
 😃
 😃😃
 😃😃😃
 😃😃😃😃
 😃😃😃😃😃
 */
